# ✈ Cork Flight Price Monitor

Monitors cheap flights from Cork (ORK) and sends a daily email digest to your inbox.
Runs **free** on GitHub Actions — no server, no cost.

---

## What it does

- Checks prices for 7 routes from Cork every morning at 08:00 Irish time
- Emails you a summary with price changes vs. the previous day
- Highlights routes that have dropped below your target price (🔔 alert)
- Tracks: London, Manchester, Amsterdam, Barcelona, Faro, Málaga, New York

---

## Setup (10 minutes)

### Step 1 — Fork / create the repo

1. Go to [github.com](https://github.com) and create a **new repository** (can be private)
2. Upload these two files:
   - `flight_monitor.py`
   - `.github/workflows/daily_monitor.yml`

### Step 2 — Create a Gmail App Password

You need a special password so the script can send email via Gmail without using your real password.

1. Go to your Google account → **Security**
2. Make sure **2-Step Verification** is ON
3. Search for **"App passwords"** → create one → name it "Flight Monitor"
4. Copy the 16-character password (e.g. `abcd efgh ijkl mnop`)

### Step 3 — Add secrets to GitHub

In your GitHub repo:
1. Go to **Settings → Secrets and variables → Actions → New repository secret**
2. Add these two secrets:

| Secret name      | Value                          |
|------------------|--------------------------------|
| `GMAIL_USER`     | your Gmail address (e.g. `you@gmail.com`) |
| `GMAIL_APP_PASS` | the 16-char app password from Step 2 |

### Step 4 — Enable Actions

1. Go to the **Actions** tab in your repo
2. Click **"I understand my workflows, go ahead and enable them"**
3. Click **"Daily Flight Price Monitor"** → **"Run workflow"** to test it now

You should receive an email within a minute! ✓

---

## Customise routes & thresholds

Edit `flight_monitor.py`:

```python
# Add or remove routes here
ROUTES = [
    ("ORK", "London",    "LON"),
    ("ORK", "Dublin",    "DUB"),   # add Dublin
    ("ORK", "Tenerife",  "TFS"),   # add Tenerife
    # ...
]

# Set your target price per destination (EUR)
PRICE_THRESHOLDS = {
    "London":     50,   # alert me if London drops below €50
    "Tenerife":   120,
    # ...
}
```

---

## Email schedule

The workflow runs at `0 7 * * *` (UTC) = **08:00 Irish time** every day.
To change it, edit the cron line in `.github/workflows/daily_monitor.yml`.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| No email received | Check Actions tab for errors; verify secrets are set correctly |
| "Less secure app" error | Make sure you used an App Password, not your real Gmail password |
| All prices show N/A | The Skyscanner API may be rate-limiting; try again tomorrow |
